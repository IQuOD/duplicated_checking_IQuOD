# -*- coding: utf-8 -*-
name='DC_OCEAN'
__author__ = 'Zhetao Tan (IAP/CAS), Xinyi Song (IAP/CAS), Lijing Cheng (IAP/CAS)'
__author__ = 'IQuOD'
__email__ = 'tanzhetao@mail.iap.ac.cn; songxinyi231@mails.ucas.ac.cn' 
__version__ = '1.2'
